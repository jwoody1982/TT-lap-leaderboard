
const csvUrl = "https://docs.google.com/spreadsheets/d/e/2PACX-1vQOUHhPhIQyhFGOCuPUH0TSfz8xTOmWEOpHjhO2-zvA5MxiFyp4Pyu4MtIALk_hG1OKUK91cCuzuDIX/pub?gid=0&single=true&output=csv";

async function loadLeaderboard() {
  const res = await fetch(csvUrl);
  const csvText = await res.text();
  const rows = csvText.split("\n").map(r => r.split(","));
  const tbody = document.querySelector("#leaderboard tbody");
  tbody.innerHTML = "";

  rows.slice(1).filter(r => r.length >= 4).forEach((row, idx) => {
    const tr = document.createElement("tr");
    const rank = idx + 1;
    tr.innerHTML = \`
      <td>\${rank}</td>
      <td>\${row[0]}</td>
      <td>\${row[1]}</td>
      <td>\${row[2]}</td>
      <td>\${row[3]}</td>
    \`;
    tbody.appendChild(tr);
  });

  document.querySelector("#search").addEventListener("input", function () {
    const term = this.value.toLowerCase();
    Array.from(tbody.rows).forEach(row => {
      row.style.display = Array.from(row.cells).some(cell =>
        cell.textContent.toLowerCase().includes(term)
      ) ? "" : "none";
    });
  });
}

loadLeaderboard();
